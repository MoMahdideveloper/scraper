#!/usr/bin/env python3
"""
Bunkr Scraper - API Module (Updated)

This module provides a FastAPI server to expose the scraper and uploader functionality via REST API.
"""

import os
import json
import asyncio
from typing import Dict, List, Optional

from fastapi import FastAPI, HTTPException, BackgroundTasks, File, UploadFile, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from scraper import BunkrScraper
from uploader import ContentUploader

# Initialize FastAPI app
app = FastAPI(
    title="Bunkr Scraper API",
    description="API for scraping content from bunkr.cr with customizable parameters",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allow all methods
    allow_headers=["*"],  # Allow all headers
)

# Initialize scraper with default config
DEFAULT_CONFIG = {
    "min_size": 0,  # No minimum size by default
    "max_size": None,  # No maximum size by default
    "daily_download_limit": None,  # No download limit by default
    "daily_upload_limit": None,  # No upload limit by default
    "download_dir": "./downloads",
    "upload_dir": "./uploads",
    "content_types": ["videos", "images", "files"],
    "time_period": "24h"
}

# Create directories
os.makedirs(DEFAULT_CONFIG["download_dir"], exist_ok=True)
os.makedirs(DEFAULT_CONFIG["upload_dir"], exist_ok=True)

# Global instances
scraper = BunkrScraper(DEFAULT_CONFIG)
uploader = ContentUploader({
    "upload_dir": DEFAULT_CONFIG["upload_dir"],
    "daily_upload_limit": DEFAULT_CONFIG["daily_upload_limit"]
})

# Background tasks
background_tasks = {}

# Models
class ScraperConfig(BaseModel):
    min_size: Optional[float] = 0
    max_size: Optional[float] = None
    daily_download_limit: Optional[float] = None
    daily_upload_limit: Optional[float] = None
    download_dir: Optional[str] = "./downloads"
    upload_dir: Optional[str] = "./uploads"
    content_types: Optional[List[str]] = ["videos", "images", "files"]
    time_period: Optional[str] = "24h"

class ContentItem(BaseModel):
    name: str
    size: float
    size_text: str
    url: str
    type: str

class ScrapingResult(BaseModel):
    videos: Optional[List[ContentItem]] = []
    images: Optional[List[ContentItem]] = []
    files: Optional[List[ContentItem]] = []

class DownloadRequest(BaseModel):
    items: List[ContentItem]

class UploadRequest(BaseModel):
    files: List[Dict]

class DownloadResult(BaseModel):
    success_count: int
    fail_count: int
    message: str

class UploadResult(BaseModel):
    success_count: int
    fail_count: int
    message: str
    errors: List[str] = []

class UsageStats(BaseModel):
    date: str
    downloaded: float
    uploaded: float
    download_limit: Optional[float]
    upload_limit: Optional[float]
    download_remaining: Optional[float]
    upload_remaining: Optional[float]
    file_count: Optional[int] = 0

class TaskStatus(BaseModel):
    id: str
    status: str
    progress: float
    result: Optional[Dict] = None

# Routes
@app.get("/")
async def root():
    """Root endpoint"""
    return {"message": "Bunkr Scraper API"}

@app.get("/config", response_model=ScraperConfig)
async def get_config():
    """Get current scraper configuration"""
    return scraper.config

@app.post("/config", response_model=ScraperConfig)
async def update_config(config: ScraperConfig):
    """Update scraper configuration"""
    # Update scraper config
    scraper.update_config(config.dict(exclude_unset=True))
    
    # Update uploader config
    uploader_config = {}
    if config.upload_dir:
        uploader_config["upload_dir"] = config.upload_dir
    if config.daily_upload_limit:
        uploader_config["daily_upload_limit"] = config.daily_upload_limit
    
    if uploader_config:
        uploader.update_config(uploader_config)
    
    return scraper.config

@app.get("/scrape", response_model=ScrapingResult)
async def scrape_content():
    """Scrape content based on current configuration"""
    try:
        result = await scraper.scrape_content()
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/download", response_model=TaskStatus)
async def download_content(request: DownloadRequest, background_tasks: BackgroundTasks):
    """
    Start a background task to download content items
    
    Returns a task ID that can be used to check the status
    """
    task_id = f"download_{len(background_tasks) + 1}"
    
    # Create a new task status
    background_tasks[task_id] = {
        "status": "pending",
        "progress": 0.0,
        "result": None
    }
    
    # Start background task
    background_tasks.add_task(
        download_content_task,
        task_id,
        request.items
    )
    
    return {
        "id": task_id,
        "status": "pending",
        "progress": 0.0,
        "result": None
    }

@app.post("/upload", response_model=UploadResult)
async def upload_content(request: UploadRequest):
    """
    Upload downloaded content to local project
    
    Args:
        request: Upload request containing file information
    
    Returns:
        Upload result with success/fail counts and error messages
    """
    try:
        success_count, fail_count, errors = uploader.upload_multiple_files(request.files)
        
        return {
            "success_count": success_count,
            "fail_count": fail_count,
            "message": f"Uploaded {success_count} of {len(request.files)} files",
            "errors": errors
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/tasks/{task_id}", response_model=TaskStatus)
async def get_task_status(task_id: str):
    """Get status of a background task"""
    if task_id not in background_tasks:
        raise HTTPException(status_code=404, detail=f"Task {task_id} not found")
    
    return {
        "id": task_id,
        **background_tasks[task_id]
    }

@app.get("/usage", response_model=UsageStats)
async def get_usage_stats():
    """Get current usage statistics"""
    scraper_stats = scraper.get_usage_stats()
    uploader_stats = uploader.get_usage_stats()
    
    # Combine stats
    combined_stats = {
        "date": scraper_stats["date"],
        "downloaded": scraper_stats["downloaded"],
        "uploaded": uploader_stats["uploaded"],
        "download_limit": scraper_stats["download_limit"],
        "upload_limit": uploader_stats["upload_limit"],
        "download_remaining": scraper_stats["download_remaining"],
        "upload_remaining": uploader_stats["upload_remaining"],
        "file_count": uploader_stats["file_count"]
    }
    
    return combined_stats

@app.get("/downloads", response_model=List[Dict])
async def list_downloads():
    """List downloaded files"""
    download_dir = scraper.download_dir
    files = []
    
    try:
        for filename in os.listdir(download_dir):
            filepath = os.path.join(download_dir, filename)
            if os.path.isfile(filepath):
                size_bytes = os.path.getsize(filepath)
                size_mb = size_bytes / (1024 * 1024)
                
                # Determine file type
                if filename.lower().endswith((".mp4", ".avi", ".mov", ".wmv", ".flv", ".mkv")):
                    file_type = "video"
                elif filename.lower().endswith((".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp")):
                    file_type = "image"
                else:
                    file_type = "file"
                
                files.append({
                    "name": filename,
                    "path": filepath,
                    "size": size_mb,
                    "size_text": f"{size_mb:.1f} MB",
                    "type": file_type
                })
        
        return files
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/uploads", response_model=List[Dict])
async def list_uploads():
    """List uploaded files"""
    upload_dir = uploader.upload_dir
    files = []
    
    try:
        for root, dirs, filenames in os.walk(upload_dir):
            for filename in filenames:
                filepath = os.path.join(root, filename)
                rel_path = os.path.relpath(filepath, upload_dir)
                
                size_bytes = os.path.getsize(filepath)
                size_mb = size_bytes / (1024 * 1024)
                
                # Determine file type based on directory
                if "videos" in rel_path:
                    file_type = "video"
                elif "images" in rel_path:
                    file_type = "image"
                else:
                    file_type = "file"
                
                files.append({
                    "name": filename,
                    "path": rel_path,
                    "size": size_mb,
                    "size_text": f"{size_mb:.1f} MB",
                    "type": file_type
                })
        
        return files
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Serve static files (downloads and uploads)
app.mount("/files", StaticFiles(directory=DEFAULT_CONFIG["download_dir"]), name="downloads")
app.mount("/uploads", StaticFiles(directory=DEFAULT_CONFIG["upload_dir"]), name="uploads")

# Background task functions
async def download_content_task(task_id: str, items: List[ContentItem]):
    """Background task to download content items"""
    try:
        # Update task status
        background_tasks[task_id]["status"] = "running"
        
        # Download content
        total_items = len(items)
        success_count = 0
        fail_count = 0
        
        for i, item in enumerate(items):
            # Get direct download URL
            download_url = await scraper.get_download_url(item["url"])
            if not download_url:
                fail_count += 1
                continue
            
            # Download file
            if await scraper.download_file(download_url, item["name"], item["size"]):
                success_count += 1
            else:
                fail_count += 1
            
            # Update progress
            background_tasks[task_id]["progress"] = (i + 1) / total_items
        
        # Update task status
        background_tasks[task_id]["status"] = "completed"
        background_tasks[task_id]["progress"] = 1.0
        background_tasks[task_id]["result"] = {
            "success_count": success_count,
            "fail_count": fail_count,
            "message": f"Downloaded {success_count} of {total_items} items"
        }
        
    except Exception as e:
        # Update task status on error
        background_tasks[task_id]["status"] = "failed"
        background_tasks[task_id]["result"] = {
            "success_count": success_count,
            "fail_count": fail_count,
            "message": f"Error: {str(e)}"
        }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
