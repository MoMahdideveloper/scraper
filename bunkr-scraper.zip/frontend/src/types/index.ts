// Types for the application

export interface ScraperConfig {
  min_size: number;
  max_size: number | null;
  daily_download_limit: number | null;
  daily_upload_limit: number | null;
  download_dir: string;
  upload_dir: string;
  content_types: string[];
  time_period: string;
}

export interface ContentItem {
  name: string;
  size: number;
  size_text: string;
  url: string;
  type: string;
}

export interface ScrapingResult {
  videos: ContentItem[];
  images: ContentItem[];
  files: ContentItem[];
}

export interface DownloadRequest {
  items: ContentItem[];
}

export interface UploadRequest {
  files: {
    path: string;
    type: string;
    size: number;
  }[];
}

export interface DownloadResult {
  success_count: number;
  fail_count: number;
  message: string;
}

export interface UploadResult {
  success_count: number;
  fail_count: number;
  message: string;
  errors: string[];
}

export interface UsageStats {
  date: string;
  downloaded: number;
  uploaded: number;
  download_limit: number | null;
  upload_limit: number | null;
  download_remaining: number | null;
  upload_remaining: number | null;
  file_count: number;
}

export interface TaskStatus {
  id: string;
  status: string;
  progress: number;
  result: any | null;
}
